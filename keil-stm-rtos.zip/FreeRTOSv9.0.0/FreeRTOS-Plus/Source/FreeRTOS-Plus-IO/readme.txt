It is not possible to create an example FreeRTOS+IO project for the Windows
simulator.  FreeRTOS+IO information can be found on http://www.FreeRTOS.org/IO.

A featured demo that includes telnet like functionality, a web server, 
a command line interface (using FreeRTOS+CLI) and a FAT file system is 
described on 
http://www.freertos.org/FreeRTOS-Plus/FreeRTOS_Plus_IO/Demo_Applications/LPCXpresso_LPC1769/NXP_LPC1769_Demo_Description.shtml