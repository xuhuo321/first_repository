/* rand.h for openSSL */

#include <wolfssl/openssl/ssl.h>
