/* dummy ecc_fp.c for dist */
